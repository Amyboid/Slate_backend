import bcrypt from 'bcrypt';

const saltRounds = 10;
const plainPassword = '123456';
const hashedPassword = '$2b$10$DZWHtGwK93Q4bjpA/V5jbeWIidOrPdg3df5RKP.cE/2ZE3sLsXhvi'


const validPassword = await bcrypt.compare(plainPassword, hashedPassword);
console.log(hashedPassword);
console.log(validPassword);



// this file is for generating temporary hash to insert in the db 


// $2b$10$DZWHtGwK93Q4bjpA/V5jbeWIidOrPdg3df5RKP.cE/2ZE3sLsXhvi       School
// $2b$10$uTdXFRBkHboFodJ5hvToQOYg6MUfMftoGEYqnfGiCFs4mD6IB5fku       Parent
// $2b$10$lUbfPBswAoe.pJClnYpsreuivvJpJtOwjHbtr43hEKpnsOXCFMw/S       Student


// INSERT INTO Users (Name, Email, Password, Role) 
// VALUES ('ABC School', 'school@slate.com', '$2b$10$DZWHtGwK93Q4bjpA/V5jbeWIidOrPdg3df5RKP.cE/2ZE3sLsXhvi', 'School');

// INSERT INTO Users (Name, Email, Password, Role, LinkedStudentID) 
// VALUES ('Rahul Gupta', 'parent@slate.com', '$2b$10$uTdXFRBkHboFodJ5hvToQOYg6MUfMftoGEYqnfGiCFs4mD6IB5fku', 'Parent', 101);

// INSERT INTO Users (Name, Email, Password, Role, LinkedStudentID) 
// VALUES ('Riya Sharma', 'student@slate.com', '$2b$10$lUbfPBswAoe.pJClnYpsreuivvJpJtOwjHbtr43hEKpnsOXCFMw/S', 'Student', 101);

// INSERT INTO StudentAchievements (StudentID, Name, SchoolName, Achievements) 
// VALUES (101, 'Riya Sharma', 'ABC School', 'Science Olympiad Winner');